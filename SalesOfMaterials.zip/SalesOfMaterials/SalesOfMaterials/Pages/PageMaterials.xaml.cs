﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMaaterials.xaml
    /// </summary>
    public partial class PageMaaterials : Page
    {
        public PageMaaterials()
        {
            InitializeComponent();
            dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void TxtMaterial_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtMaterial.Text.Count() != 0) dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Name.ToLower().Contains(TxtMaterial.Text.ToLower()) || x.Type.Name.ToLower().Contains(TxtMaterial.Text.ToLower()) || x.DrawingNumber.ToLower().Contains(TxtMaterial.Text.ToLower())).ToList();
            else dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
        }
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddMaterials((Materials)dgMaterials.SelectedItem));
        }

        private void MenuAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddMaterials(null));
        }

        private void MenuDelet_Click(object sender, RoutedEventArgs e)
        {
            List<Materials> delet = dgMaterials.SelectedItems.Cast<Materials>().ToList();
            if (MessageBox.Show("Удалить данные", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (Materials s in delet)
                    {
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Storage where idMaterial = @id", new SqlParameter("@id", s.idMaterial));
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Hierarchy where idParent = @id or idChild = @id", new SqlParameter("@id", s.idMaterial));
                        ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Materials where idMaterial = @id", new SqlParameter("@id", s.idMaterial));
                    }
                    MessageBox.Show("Данные удаленны");
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void MenuFilter_Click(object sender, RoutedEventArgs e)
        {
            MenuItem m = sender as MenuItem;
            switch (m.Header)
            {
                case "Изделие":
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Type.Name == "Изделие").ToList();
                    break;
                case "Узел":
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Type.Name == "Узел").ToList();
                    break;
                case "Деталь":
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Type.Name == "Деталь").ToList();
                    break;
                case "Материал":
                    dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").Where(x => x.Type.Name == "Материал").ToList();
                    break;
            }
        }

        private void MenuClear_Click(object sender, RoutedEventArgs e)
        {
            dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgMaterials.ItemsSource = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}
