﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddСounterparties.xaml
    /// </summary>
    public partial class AddСounterparties : Page
    {
        public Classes.Сounterparties _currentItem = new Classes.Сounterparties();
        public AddСounterparties(Classes.Сounterparties selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtNazv.Text == "" && txtINN.Text == "" && txtAdress.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (_currentItem.IdСounterparties == 0) ClassFrame.db.Сounterparties.Add(_currentItem);
            try
            {
                ClassFrame.db.SaveChanges();
                ClassFrame.frmObj.Navigate(new Сounterparties());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
