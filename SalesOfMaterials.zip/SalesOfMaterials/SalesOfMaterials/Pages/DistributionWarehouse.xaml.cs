﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionWarehouse.xaml
    /// </summary>
    public partial class DistributionWarehouse : Page
    {
        ExpenseIvoices expense = new ExpenseIvoices();
        public DistributionWarehouse(ExpenseIvoices selected)
        {
            InitializeComponent();
            if(selected != null) expense = selected;
            cmbMaterial.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList();
        }

        private void cmbMaterial_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbMaterial.SelectedItem is ExpenseComposition c)
            {
                int? q = ClassFrame.db.Database.SqlQuery<int?>("select sum(PartofQuantity) from Nomenclature.dbo.Movement M join SalesOfMaterial.dbo.ExpenseComposition E on E.IdExpenseComposition = M.idComposition where IdMaterial = @material  and ArrivalOrExpenditure = 1 and IdExpenseIvoices = @ivoce", new SqlParameter("@material", c.Material.idMaterial), new SqlParameter("@ivoce", c.IdExpenseIvoices)).Single();
                List<Storage> list = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage where idMaterial = @id", new SqlParameter("@id", c.IdMaterial)).ToList();
                foreach (Storage s in list) s.QuantityComposition = ClassFrame.db.Database.SqlQuery<int?>("select sum(PartOfQuantity) from Nomenclature.dbo.Movement M join SalesOfMaterial.dbo.ExpenseComposition C on C.IdExpenseComposition = M.idComposition where M.idComposition = @idC and idMaterial = @idM and idWarehouse = @idW and ArrivalOrExpenditure = 1", new SqlParameter("@idC", c.IdExpenseComposition), new SqlParameter("@idM", c.IdMaterial), new SqlParameter("idW", s.idWarehouse)).Single() == null ? 0 : ClassFrame.db.Database.SqlQuery<int>("select sum(PartOfQuantity) from Nomenclature.dbo.Movement M join SalesOfMaterial.dbo.ExpenseComposition C on C.IdExpenseComposition = M.idComposition where M.idComposition = @idC and idMaterial = @idM and idWarehouse = @idW and ArrivalOrExpenditure = 1", new SqlParameter("@idC", c.IdExpenseComposition), new SqlParameter("@idM", c.IdMaterial), new SqlParameter("@idW", s.idWarehouse)).Single();
                dgWarhouse.ItemsSource = list;
                txtCount.DataContext = ClassFrame.db.ExpenseComposition.FirstOrDefault(x => x.IdExpenseIvoices == expense.IdExpenseIvoices && x.IdMaterial == c.IdMaterial);
                if (q != null) txtCount.Text = ((cmbMaterial.SelectedItem as ExpenseComposition).Quantity - q).ToString();
                else txtCount.Text = (cmbMaterial.SelectedItem as ExpenseComposition).Quantity.ToString();
            }
            if (Convert.ToInt32(txtCount.Text) == 0)
            {
                txtPosition.Text = "Позиция закрыта";
            }
            else
                txtPosition.Text = "";
            quantityComposition.IsReadOnly = false;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            ExpenseComposition c = cmbMaterial.SelectedItem as ExpenseComposition;
            if (txtSearch.Text.Count() != 0)
                dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial && x.Warehouse.Name.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
            else dgWarhouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.idMaterial == c.IdMaterial).ToList();
        }

        private void DgWarhouse_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            int quantity = ((List<Storage>)dgWarhouse.ItemsSource).Sum(x => x.QuantityComposition);
            txtCount.Text = ((cmbMaterial.SelectedItem as ExpenseComposition).Quantity - quantity).ToString();
            if (Convert.ToInt32(txtCount.Text) == 0)
            {
                txtPosition.Text = "Позиция закрыта";
                dgWarhouse.ItemsSource = (dgWarhouse.ItemsSource as List<Storage>).Where(x => x.QuantityComposition != 0).ToList();
                quantityComposition.IsReadOnly = true;
            }
        }

        private void MenuDistribute_Click(object sender, RoutedEventArgs e)
        {
            List<Storage> list = dgWarhouse.ItemsSource as List<Storage>;
            foreach (Storage s in list)
            {
                if (s.QuantityComposition > s.Quantity)
                {
                    MessageBox.Show("Количество забираемого товара больше чем количество хранящиеся на складе", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
            if (Convert.ToInt32(txtCount.Text) < 0)
            {
                MessageBox.Show("Количество забираемого товара больше чем нужно", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Convert.ToInt32(txtCount.Text) > 0)
            {
                MessageBox.Show("Количество забираемого товара меньше чем нужно", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            foreach (Storage s in list)
            {
                try
                {
                    ClassFrame.db.Database.ExecuteSqlCommand("insert into Nomenclature.dbo.Movement values (@warehouse,@composition,@user,@quantity,1)", new SqlParameter("@warehouse", s.idWarehouse), new SqlParameter("@composition", ((ExpenseComposition)cmbMaterial.SelectedItem).IdExpenseComposition), new SqlParameter("@user", Users.GetUsers.ID), new SqlParameter("@quantity", s.QuantityComposition));
                    ClassFrame.db.Database.ExecuteSqlCommand("update Storage set Quantity = Storage.Quantity - @quantity from Nomenclature.dbo.Storage where idMaterial = @material and  idWarehouse = @warhouse", new SqlParameter("@quantity", s.QuantityComposition), new SqlParameter("@material", s.idMaterial), new SqlParameter("@warhouse", s.idWarehouse));
                    ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Storage where idMaterial = @material and Quantity = 0 and idWarehouse = @warhouse", new SqlParameter("@material", s.idMaterial), new SqlParameter("@warhouse", s.idWarehouse));
                    if (Convert.ToInt32(txtCount.Text) == 0)
                        txtPosition.Text = "Позиция закрыта";


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            MessageBox.Show("Товар Распределён", "Уведомление", MessageBoxButton.OK);
            cmbMaterial.SelectedIndex = cmbMaterial.SelectedIndex + 1;
        }

        private void MenuСheck_Click(object sender, RoutedEventArgs e)
        {
            foreach (ExpenseComposition expense in cmbMaterial.ItemsSource)
            {
                int? d = ClassFrame.db.Database.SqlQuery<int?>($"select sum(PartOfQuantity) from Nomenclature.dbo.Movement where idComposition = {expense.IdExpenseComposition} and ArrivalOrExpenditure = 1").Single();
                if (d == null) d = 0;
                if (d != expense.Quantity)
                {
                    MessageBox.Show($"Товар \"{expense.Material.Name}\" не закрыт.", "Уведомление", MessageBoxButton.OK);
                    return;
                }
            }
            try
            {
                expense.DistributedInvoice = true;
                ClassFrame.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Заказ закрыт", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            ClassFrame.frmObj.Navigate(new PageOrder());
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            cmbMaterial.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == expense.IdExpenseIvoices).ToList();
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }
    }
}
