﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для Movment.xaml
    /// </summary>
    public partial class Movment : Page
    {
        public Movment()
        {
            InitializeComponent();
            dgMovement.ItemsSource = ClassFrame.db.Database.SqlQuery<Movement>("select * from Nomenclature.dbo.Movement").ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtSearch.Text.Count() != 0)
                dgMovement.ItemsSource = ClassFrame.db.Database.SqlQuery<Movement>("select * from Nomenclature.dbo.Movement").Where(x => x.Warehouse.Name.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
            else dgMovement.ItemsSource = ClassFrame.db.Database.SqlQuery<Movement>("select * from Nomenclature.dbo.Movement").ToList();
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}
