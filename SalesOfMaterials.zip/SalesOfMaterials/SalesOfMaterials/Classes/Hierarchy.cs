﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Hierarchy
    {
        public int idHierarchy { get; set; }
        public int idParent { get; set; }
        public int idChild { get; set; }
        public int Quantity { get; set; }
        public virtual Materials Material { get { return ClassFrame.db.Database.SqlQuery<Materials>($"select * from Nomenclature.dbo.Materials where idMaterial = {idParent}").First(); } }
        public virtual Materials Material1 { get { return ClassFrame.db.Database.SqlQuery<Materials>($"select * from Nomenclature.dbo.Materials where idMaterial = {idChild}").First(); } }

    }
}
